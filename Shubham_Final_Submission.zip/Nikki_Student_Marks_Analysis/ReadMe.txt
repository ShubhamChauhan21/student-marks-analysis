How to run:
1. pip install streamlit pandas matplotlib seaborn
2. streamlit run app.py
