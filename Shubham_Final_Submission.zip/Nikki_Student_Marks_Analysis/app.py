
import streamlit as st
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

st.set_page_config(page_title="Student EDA Dashboard", layout="wide")
st.title("📊 Student Marks EDA & Statistics Dashboard")

st.sidebar.title("📌 Project Info")
st.sidebar.markdown("**Submitted by:** Nikki Chauhan")
st.sidebar.markdown("**Topic:** EDA & Descriptive Statistics Tool")
st.sidebar.markdown("**College:** [Your College Name]")

uploaded_file = st.file_uploader("📁 Upload your CSV file", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)

    st.subheader("📄 Data Preview")
    st.dataframe(df)

    st.subheader("🏅 Student Ranking (by Total Marks)")
    df["Total"] = df[["Math", "English", "Science"]].sum(axis=1)
    df_sorted = df.sort_values(by="Total", ascending=False)
    st.dataframe(df_sorted[["Name", "Total", "Grade"]].reset_index(drop=True))

    st.subheader("🔍 Filter by Student Name")
    student_names = df["Name"].unique()
    selected_name = st.selectbox("Choose a student", student_names)
    st.write(df[df["Name"] == selected_name])

    st.subheader("📊 Subject-wise Averages")
    st.write(df[["Math", "English", "Science"]].mean())

    st.subheader("🚫 Missing Values")
    st.write(df.isnull().sum())

    st.subheader("📈 Descriptive Statistics")
    st.write(df.describe())

    st.subheader("📉 Distribution Plots")
    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
    for col in numeric_cols:
        fig, ax = plt.subplots()
        sns.histplot(df[col], kde=True, ax=ax)
        ax.set_title(f"Distribution of {col}")
        st.pyplot(fig)

    st.subheader("📌 Correlation Heatmap")
    fig2, ax2 = plt.subplots(figsize=(8, 4))
    sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm", ax=ax2)
    st.pyplot(fig2)

    if "Grade" in df.columns:
        st.subheader("🎓 Grade Distribution")
        grade_counts = df["Grade"].value_counts()
        fig3, ax3 = plt.subplots()
        ax3.pie(grade_counts, labels=grade_counts.index, autopct='%1.1f%%', startangle=90)
        ax3.set_title("Grade Distribution")
        st.pyplot(fig3)

else:
    st.info("⬆️ Please upload a CSV file to begin analysis")
